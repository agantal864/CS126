<?php
    //start of session
    session_start();
    //establish a connection
    $connect = mysqli_connect('localhost', 'aamagantal', '12345', 'students');
    if (!$connect) {
      echo 'Connection error'. mysqli_connect_error();
    }
    //Insert student data to database
    if (isset($_POST['submit'])) {
      $lastname = mysqli_real_escape_string($connect, $_POST['LastName']);
      $firstname = mysqli_real_escape_string($connect, $_POST['FirstName']);
      $email = mysqli_real_escape_string($connect, $_POST['Email']);

      //insert query save to variable sql
      $sql = "INSERT INTO studentinfo (LastName, FirstName, Email) VALUES ('$lastname', '$firstname', '$email')";

      if (mysqli_query($connect, $sql)) {
        $_SESSION['success'] = 'Student added!';
        //Successfully added to database
        header("Location: index.php");
      } else {
        echo 'query error ' . mysqli_error($connect);
      }
    }
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="mystyles.css">
    <title>Add Student</title>
  </head>
  <body>
    <br /><br />
      <div class="container">
          <div class="row">
              <div class="col-4 mx-auto">
                <form class="formstyle" autocomplete="off" action="add.php" method="post">
                    <h2 style="text-align: center">ADD A STUDENT</h2>
                    <br/>

                    <div class="form-group">
                      <label for="LastName">Last Name</label>
                      <input type="text" name="LastName">
                    </div>

                    <div class="form-group">
                      <label for="FirstName">First Name</label>
                      <input type="text" name="FirstName">
                    </div>

                    <div class="form-group">
                      <label for="Email">Email</label>
                      <input type="email" name="Email">
                    </div>
                    <br />

                    <input class="btn btn-dark" type="submit" name="submit" value="Submit">

                </form>
              </div>
          </div>
      </div>
  </body>
</html>
