<?php
    //start of session
    session_start();
    //establish a connection
    $connect = mysqli_connect('localhost', 'aamagantal', '12345', 'students');
    if (!$connect) {
      echo 'Connection error'. mysqli_connect_error();
    }
    //get the passed value in hyperlink
    $thisEmail = $_GET['CopyEmail'];
    //make a DELETE query
    $delete = "DELETE FROM studentinfo WHERE Email='$thisEmail'";
    //Redirect if successfull or show error
    if (mysqli_query($connect, $delete)) {
      $_SESSION['success'] = 'Student deleted!';
      //Successfully added to database
      header("Location: index.php");
    } else {
      echo 'query error ' . mysqli_error($connect);
    }
 ?>
