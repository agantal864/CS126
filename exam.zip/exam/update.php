<?php
      //establish a connection
      $connect = mysqli_connect('localhost', 'aamagantal', '12345', 'students');
      if (!$connect) {
        echo 'Connection error'. mysqli_connect_error();
      }
      //get the passed value in hyperlink
      $ID = $_GET['GETID'];
      //make a SELECT query
      $query = "SELECT * FROM studentinfo WHERE ID = '".$ID."'";
      //save the row data in the variable 'result' after selecting the appropriate ID of the row
      $result = mysqli_query($connect, $query);
      //fetch the data and save as an associative array in the variable 'row'
      while ($row = mysqli_fetch_assoc($result)) {
        $ID = $row['ID'];
        $Lname = $row['LastName'];
        $Fname = $row['FirstName'];
        $Email = $row['Email'];
      }
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">

  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="mystyles.css">
    <title>Update Student</title>
  </head>
  <body>
    <br /><br />
      <div class="container">
          <div class="row">
              <div class="col-4 mx-auto">
                <form class="formstyle" autocomplete="off" action="updateinfo.php?id=<?php echo $ID ?>" method="POST">
                    <h2 style="text-align: center">UPDATE INFO</h2>
                    <br/>

                    <div class="form-group">
                      <label for="LastName">Last Name</label>
                      <input type="text" name="LastName" value="<?php echo $Lname ?>">
                    </div>

                    <div class="form-group">
                      <label for="FirstName">First Name</label>
                      <input type="text" name="FirstName" value="<?php echo $Fname ?>">
                    </div>

                    <div class="form-group">
                      <label for="Email">Email</label>
                      <input type="email" name="Email" value="<?php echo $Email ?>">
                    </div>
                    <br />

                    <input class="btn btn-dark" type="submit" name="update" value="Update">

                </form>
              </div>
          </div>
      </div>
  </body>
</html>
