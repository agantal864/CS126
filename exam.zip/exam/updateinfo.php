<?php
    //start of session
    session_start();
    //establish a connection
    $connect = mysqli_connect('localhost', 'aamagantal', '12345', 'students');
    if (!$connect) {
      echo 'Connection error'. mysqli_connect_error();
    }
    //if $_POST['update'] != NULL, save the data to a separate variable
    if(isset($_POST['update'])) {
        $ID = $_GET['id'];
        $Lname = $_POST['LastName'];
        $Fname = $_POST['FirstName'];
        $Email = $_POST['Email'];
        //Make an UPDATE query
        $update = "UPDATE studentinfo SET LastName = '".$Lname."', FirstName = '".$Fname."', Email = '".$Email."' WHERE ID = '".$ID."'";
        //Redirect if successfull or show error
        if (mysqli_query($connect, $update)) {
          $_SESSION['success'] = 'Student updated!';
          //Successfully added to database
          header("Location: index.php");
        } else {
          echo 'query error ' . mysqli_error($connect);
        }
    }
 ?>
