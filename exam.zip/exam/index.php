<?php
    //Sessions are used here to display information - 'success' variable is used across the pages
    session_start();
    //establish a connection
    $connect = mysqli_connect('localhost', 'aamagantal', '12345', 'students');
    if (!$connect) {
      echo 'Connection error'. mysqli_connect_error();
    }
    //Get the data from the database
    $data = 'SELECT * FROM studentinfo';
    //save the data in the variable 'result'
    $result = mysqli_query($connect, $data);
    //fetch data and save in 'infos' as an associatve array
    $infos = mysqli_fetch_all($result, MYSQLI_ASSOC);
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="mystyles.css">
    <title>Exam</title>
  </head>
  <body>
          <br />
          <!--This is where the message is displayed / When the array is not emply then it prints a message-->
          <?php if (isset($_SESSION['success'])): ?>
              <div class="box">
                    <?php
                        //displays the message of the current value of the array
                        echo $_SESSION['success'];
                        //unsets the variable to be reused by other pages
                        unset($_SESSION['success']);
                     ?>
              </div>
          <?php endif; ?>
          <div class="container">
              <div class="row">
                  <div class="col-lg-12 mx-auto">

                      <div class="table-responsive" style="border: 5px solid gray; border-radius: 15px;">
                        <table class="table-dark table-bordered table-hover">

                          <thead>
                            <th colspan="4">
                              <h1>CMSC 11 CLASS</h1>
                            </th>
                          </thead>

                          <thead>
                            <th></th>
                            <th></th>
                            <th></th>
                            <th>
                              <p id="add"><button type="button" class="btn btn-outline-light" style="width: 80%"><a href="add.php">ADD</a></button></p>
                            </th>
                          </thead>

                          <thead>
                            <tr style="background: gray;">
                              <th>Last Name</th>
                              <th>First Name</th>
                              <th>Email</th>
                              <th class="action">Action</th>
                            <tr>
                          </thead>

                          <tbody>
                                <!-- Display the data as a row -->
                                <?php  foreach($infos as $info) {?>
                                  <tr>
                                    <td><?php echo htmlspecialchars($info['LastName']); ?></td>
                                    <td><?php echo htmlspecialchars($info['FirstName']); ?></td>
                                    <td><?php echo htmlspecialchars($info['Email']); ?></td>
                                    <?php
                                      //Save the Email and ID data to be used in updating and deleting records
                                      $EmailInfo = $info['Email'];
                                      $IDinfo = $info['ID'];
                                     ?>
                                    <td class="action">

                                      <button type="button" class="btn btn-outline-light" style="width: 40%">
                                        <a href="update.php?GETID=<?php echo $IDinfo; ?>">EDIT</a>
                                      </button>
                                      &nbsp;&nbsp;
                                      <button type="button" class="btn btn-outline-light" style="width: 40%">
                                        <a href="delete.php?CopyEmail=<?php echo $EmailInfo; ?>">DELETE</a>
                                      </button>

                                    </td>
                                  </tr>
                                <?php } ?>
                          </tbody>

                        <table>
                      </div>

                  </div>
              </div>
          </div>


  </body>
</html>
